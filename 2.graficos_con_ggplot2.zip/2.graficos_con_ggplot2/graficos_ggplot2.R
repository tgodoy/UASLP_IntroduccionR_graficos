#!/usr/bin/env Rscript
#  graficos_ggplot2.R
#  Copyright 2023- E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Texto sin acentos

###################################################
#### Introduccion a R y Visualización de datos ####
####             Graficos con ggplot2          ####
####           E. Ernestina Godoy Lozano       ####
###################################################

#########################################################
####           Instalar librerias de trabajo         ####
#########################################################

#install.packages("ggplot2")
#install.packages("reshape2")


#########################################################
####           Cargar librerias de trabajo           ####
#########################################################

library(ggplot2)
getwd()

#########################################################
####               Ejercicio: qplot()                ####
####             Diapositivas: 16-22                 ####
#########################################################

# Ejercicio rapido de qplot()
# Usar datos de un data.frame con datos reales, "abiotic_variables.txt"
# Leer datos
abiotic <- read.delim("tablas/abiotic_variables.txt", 
                      header=T, row.names=1)

# Explorar los datos
View(abiotic)
dim(abiotic)
summary(abiotic)

qplot(x=Naphthalene, y=Deep, data=abiotic)

# Smoothing (agregar una linea suavizada con su error estandar)
qplot(x=Naphthalene, y=Deep, 
      data = abiotic, geom = c("point", "smooth"))

# Cambiar el color por una variable numerica continua (Organic_Matter)
View(abiotic)
qplot(x=Naphthalene, y=Deep, data = abiotic, 
      colour = Organic_Matter)

# Cambiar el color por grupos (factor)
abiotic_mod <- abiotic

# Transformar el tipo de variable a factor
abiotic_mod$Class <- factor(abiotic_mod$Class, levels = c("Costa", "Someras", "Profundas"))
summary(abiotic_mod)

qplot(x=Naphthalene, y=Deep, data = abiotic_mod, 
      colour = Class)

# Añadir lineas
qplot(Naphthalene, Deep, data = abiotic_mod, 
      colour = Class,geom=c("point", "line"))


#########################################################
####               Ejercicio: ggplot()               ####
####             Diapositivas: 23-45                 ####
#########################################################

## Usaremos un set de datos simulado "antibodies". Datos que provienen de pacientes recuperados de Dengue
# Explorar los datos
antibodies <- read.delim("tablas/antibodies.txt", header=T)
View(antibodies)
summary(antibodies)
dim(antibodies)

# generar categorias de acuerdo a los genes unicos del segmento IGHV
genes_unicos <- sort(unique(antibodies$V.GENE))
antibodies$V.GENE <- factor(antibodies$V.GENE, levels = genes_unicos)
summary(antibodies)

# Agregar datos a un objeto con la funcion ggplot ()
p <- ggplot(data=antibodies)
p

## Añadir aesthetics
p <- p + aes(x= CDR3.length, y = VJ.identity, colour = V.GENE)
p

### Otra forma de hacer el codigo anterior en una sola linea
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE))

### Vamos a explorar nuestro objeto "p"
summary(p)

## Agregar capas (layers)
p <- p + geom_point()
p

# Añadiendo transformaciones estadisticas de los datos. En este caso estamos usando una recta ajustada por cuadrados minimos
p <- p + geom_smooth(method="lm")
p

### Hazlo en una linea
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point() + geom_smooth(method="lm")

### Cambiar el tipo de objeto geometrico
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_boxplot()

### Agregar mas de un tipo de objeto geometrico
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_boxplot() + geom_point()

### Cambio de colores manual
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_boxplot() + geom_point() +
  scale_colour_manual(values=c("red", "gold", "deepskyblue"))

### Cambio de colores por paleta
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_boxplot() + geom_point() +
  scale_colour_brewer(palette = "Set1")

### Otras paletas de colores
library(paletteer)
paletteer_dynamic("ggthemes_solarized::blue", 3)

ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_boxplot() + geom_point() +
  scale_colour_manual(values=paletteer_dynamic("ggthemes_solarized::blue", 3))

## Facet grid (Cuadricula de facetas)
### Cuadricula Horizontal
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point() + geom_smooth(method="lm") +
  facet_grid(~ V.GENE)

### Cuadricula Vertical
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point() + geom_smooth(method="lm") +
  facet_grid(V.GENE ~.)

### Quitar leyenda
ggplot(data=antibodies, aes(x=CDR3.length, y=VJ.identity, colour=V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.)

## Cambio de temas
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.) +
  theme_bw()

### Probemos un tema mas
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.) +
  theme_linedraw()

#  Cambiar otros elementos en el tema
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + geom_smooth(method="lm", show.legend = FALSE) +
  facet_grid(V.GENE~.) +
  theme_bw() +
  theme(panel.background = element_rect(fill = "black"), 
        panel.grid.minor = element_line(linetype = "dotted"))


#### Guardar imagenes

# En que directorio me encuentro
getwd()
dir()

# Primera opcion
### PNG con una resolucion de 300 px
png("figuras/dot_plot_antibodies_data.png", width=10 *300, height=8*300, res= 300)
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + 
  facet_grid(V.GENE~.) +
  scale_colour_manual(values=paletteer_d("wesanderson::Darjeeling1")) +
  theme_linedraw()
dev.off()

### PDF (Imagen vectorizada)
pdf("figuras/dot_plot_antibodies_data.pdf", width=10, height=8)
ggplot(data=antibodies, aes(x = CDR3.length, y = VJ.identity, colour = V.GENE)) + 
  geom_point(show.legend = FALSE) + 
  facet_grid(V.GENE~.) +
  scale_colour_manual(values=paletteer_d("vapoRwave::newRetro")) +
  theme_linedraw()
dev.off()

# Segunda opcion con una funcion propia de ggplot2
ggsave("figuras/dot_plot_antibodies_data.jpg", device= "jpg")

