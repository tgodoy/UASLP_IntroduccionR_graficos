#!/usr/bin/env Rscript
#  graficos_ggpurb.R
#  Copyright 2023- E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Texto sin acentos

################################################
####       Graficos para publicacion        ####
####             ggpurb y ggplot2           ####
####        E. Ernestina Godoy Lozano       ####
################################################

#########################################################
####           Instalar librerias de trabajo         ####
#########################################################

#install.packages("ggplot2")
#install.packages("reshape2")
#install.packages("ggpubr")


#########################################################
####           Cargar librerias de trabajo           ####
#########################################################

library(ggplot2)
library(ggpubr)

## Usaremos un set de datos simulado "antibodies". Datos que provienen de pacientes recuperados de Dengue
# Explorar los datos
antibodies <- read.delim("tables/antibodies.txt", header=T)
View(antibodies)
summary(antibodies)
dim(antibodies)

# generar categorias de acuerdo a los genes unicos del segmento IGHV
genes_unicos <- sort(unique(antibodies$V.GENE))
antibodies$V.GENE <- factor(antibodies$V.GENE, levels = genes_unicos)
summary(antibodies)

# Distribucion
# Observar la distribucion de los tamaños del CDR3 de acuerdo al gen IGHV

gghistogram(antibodies, x = "CDR3.length",
            rug = FALSE, 
            color = "V.GENE", # Variable con la que se toma el color
            fill = "V.GENE", # Varaible con la que se toma elrelleno
            bins = 20)

# Cambiar colores, añadir linea de tendencia
gghistogram(antibodies, x = "CDR3.length",
          add = "mean",  # Agregar la linea de tendencia ("median",  "mean")
          rug = TRUE,
          color = "V.GENE", 
          fill = "V.GENE",
          bins = 20,
          palette = c("#FF5733", "#773AA0", "#FFC300"))

# Añadir tambien la densidad
gghistogram(antibodies, x = "CDR3.length",
            add = "mean",  # Agregar la linea de tendencia ("median",  "mean")
            rug = TRUE,
            color = "V.GENE", 
            fill = "V.GENE",
            bins = 20,
            palette = c("#FF5733", "#773AA0", "#FFC300"),
            add_density=TRUE)

# Cambiar a densidad
ggdensity(antibodies, x = "CDR3.length",
          add = "mean", rug = TRUE,
          color = "V.GENE", fill = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300"))

# Añadir facetas
ggdensity(antibodies, x = "CDR3.length",
          add = "mean", rug = TRUE,
          color = "V.GENE", fill = "V.GENE",
          facet.by = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300"))

# Cambiar los nombres de los ejes y el tema
ggdensity(antibodies, x = "CDR3.length",
          add = "mean", rug = TRUE,
          color = "V.GENE", fill = "V.GENE",
          facet.by = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300")) + 
  labs(x= "CDR3 length (bp)", y= "Density", fill="", color="") + 
  theme_cleveland() +
  theme(legend.position = "none")

# guardar grafico
ggsave("figures/density_CDR3.png", device = "png", dpi = 300)


# Box plots y violin plots
# Numero de mutaciones de acuerdo al gen V
ggboxplot(antibodies, x= "V.GENE", y = "V.Nb.mutations", 
          color = "V.GENE", fill = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300"))

## Añadir barras de error y muescas
ggboxplot(antibodies, x= "V.GENE", y = "V.Nb.mutations", 
          color = "V.GENE", fill = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = TRUE)

# Cambiar las etiquetas de los ejes y añadir los puntos
ggboxplot(antibodies, x= "V.GENE", y = "V.Nb.mutations", 
          color = "V.GENE", fill = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = TRUE, 
          xlab = "", 
          ylab= "Mutations (n)", 
          add = "jitter") +
  rremove("legend") # quitar leyenda

# Añadir comparaciones estadisticas
# Determinar el tipo de datos con el que voy a realizar las comparaciones
# Aplicamos una prueba de normalidad

shapiro.test(antibodies$V.Nb.mutations)

# Si el resultado de p < 0.05 los datos son No parametricos
##  2 distribuciones ---> wilcoxon.test
##  +2 distribuciones --->  Kruskal-Wallis
# Si el resultado de p > 0.05 los datos son Parametricos
##  2 distribuciones ---> t.test
##  +2 distribuciones --->  anova


# generar una lista con las comparaciones
mis_comparaciones <-  list(c("IGHV1-69", "IGHV2-5"), 
                           c("IGHV1-69", "IGHV3-73"),  
                           c("IGHV2-5", "IGHV3-73"))

ggboxplot(antibodies, x= "V.GENE", y = "V.Nb.mutations", 
          color = "V.GENE", fill = "V.GENE",
          palette = c("#FF5733", "#773AA0", "#FFC300"),
          bxp.errorbar = TRUE, 
          notch = TRUE, 
          xlab = "", 
          ylab= "Mutations (n)", 
          add = "jitter") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparaciones, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 70, method = "kruskal.test")

# Convertirlo a violin añadiendo el boxplot
ggviolin(antibodies, x = "V.GENE", y = "V.Nb.mutations", 
         fill = "V.GENE",
         palette = c("#FF5733", "#773AA0", "#FFC300"),
         add = "boxplot", 
         add.params = list(fill = "white"),
         xlab="", 
         ylab = "Mutations (n)") + 
  labs(color="", fill="") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparacionnes, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 70, method = "kruskal.test")

#### dot chart
## generar un grafico que refleje el % identidad del VJ con
# respecto al tamaño del CDR3 y al tipo de gen V
ggdotchart(antibodies, x = "V.GENE", y = "CDR3.length",
           color = "VJ.identity",
           sorting = "ascending",
           add = "segments",
           ggtheme = theme_pubr()) 

# Modificar escala de colores continua y ejes
ggdotchart(antibodies, x = "V.GENE", y = "CDR3.length",
           color = "VJ.identity",
           sorting = "ascending",
           add = "segments",
           ggtheme = theme_pubr(),
           rotate = TRUE) +
  labs(x="", y="CDR3 length (bp)", color="VJ identity (%)") +
  scale_colour_gradient(low = "orange", high = "purple4")

#### Graficos para publicaciones
# Escoger los graficos finales para publicacion
# Guardarlos en un objeto

A <- ggdensity(antibodies, x = "CDR3.length",
               add = "mean", rug = TRUE,
               color = "V.GENE", fill = "V.GENE",
               facet.by = "V.GENE",
               palette = c("#FF5733", "#773AA0", "#FFC300")) + 
  labs(x= "CDR3 length (bp)", y= "Density", fill="", color="") + 
  theme_cleveland()

B <- ggdotchart(antibodies, x = "V.GENE", y = "CDR3.length",
                color = "VJ.identity",
                sorting = "ascending",
                add = "segments",
                ggtheme = theme_pubr(),
                rotate = TRUE) +
  labs(x="", y="CDR3 length (bp)", color="VJ identity (%)") +
  scale_colour_gradient(low = "orange", high = "purple4")

C <- ggviolin(antibodies, x = "V.GENE", y = "V.Nb.mutations", 
              fill = "V.GENE",
              palette = c("#FF5733", "#773AA0", "#FFC300"),
              add = "boxplot", 
              add.params = list(fill = "white"),
              xlab="", 
              ylab = "Mutations (n)") + 
  labs(color="", fill="") +
  rremove("legend") +
  stat_compare_means(comparisons = mis_comparacionnes, 
                     label = "p.signif",
                     method = "wilcox.test")  +
  stat_compare_means(label.y = 70, method = "kruskal.test")

ggarrange(A, B, C, ncol = 2, nrow = 2, labels = c("A", "B", "C"))

# Ordenarlas mejor
BC <- ggarrange(B, C, ncol = 2, nrow = 1, labels = c("B", "C"))
ggarrange(A, BC, ncol = 1, nrow = 2, labels = c("A"))

ggsave("figures/Fig1ABC.png", device= "png", height = 8, width = 12)
