########################################################################
#########  Curso: Introducción a R y Visualizacion de Datos    #########
######### E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)  #########
#########                     Introduccion a R                 #########
#########                     Comandos basicos                 #########
########################################################################

# Texto sin acentos

### ORGANIZACION DE ESPACIO DE TRABAJO

# En donde estamos parados
getwd()

### Ejercicio 1.1 Instalacion de librerias de CRAN
# No lo vamos a correr
#install.packages("vegan", dependencies=T)

### Ejercicio 1.2 Instalacion de librerias de Bioconductor
# No lo vamos a correr
#if (!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")

### Ejercicio 2. Cargar librerias 
library(vegan)

### Ejercicio 3. Listado de variables e Informacion de la sesion
ls()
sessionInfo()

### Ejercicio 4. Variables

variable_caracter <- "Caracteres"
variable_caracter
variable_numerica <- 1029
variable_numerica
variable_logica <- TRUE
variable_logica

variable_Caracter2 <- "1029"

# Ejercicio 5. Determinar la clase de mis variables usando la funcion class()
class(variable_caracter)
class(variable_numerica)
class(variable_logica)
class(variable_Caracter2)

### Ejercicio 6. Operaciones basicas
x <- 5
y <- 10

length(x)
length(y)

## Operaciones basicas
suma <- x + y
suma

multiplicacion <- x * y
multiplicacion

resta <- x - y
resta

division <- x/y 
division

(x+y)^2

# Generacion de variables mas complejas
x <- seq (1,10,1)
y <- rep (2,10)
y1 <- c(5,6)

# Exploracion de las dimenciones de mis objetos
length(x)
length(y)
length(y1)

# Operaciones basicas
suma <- x + y
suma
x/y1

multiplicacion <- x * y
multiplicacion

resta <- x - y
resta

division <- x/y 
division

# Adicionar mas de un caracter o un numero a mi variable
numeros <- c(10,22,30)
numeros
letras <- c("A", "B", "C")
letras
ambos <- c("A", 15, "B", 30)
ambos
ambos <- c(15, "A", 30, "B")
ambos

# Pegado de textos
texto <- c(rep ("gen",5), rep ("protein",5))
paste (texto, x, sep="-")

### Ejercicio 7. Creacion de listas
vector <- 1:10
matriz <- matrix(1:4, nrow = 2)
df <- data.frame("numeros" = 1:3, "letras" = c("a", "b", "c"))

lista <- list("vector" = vector, 
                 "matriz" = matriz, 
                 "df" = df)

lista

# lista de listas
lista_recursiva <- list("lista1" = lista, "lista2" = lista)
lista_recursiva

# Propiedades de la lista
class(lista_recursiva)
length(lista_recursiva)
dim(lista_recursiva)

# Accediento a cada elemento de la lista
dim(lista_recursiva$lista1$un_df)

### Ejercicio 8. Data input

# Leer tabla "abiotic_variables.txt"
variables <- read.delim("tablas/abiotic_variables.txt", header = TRUE)

# Observar la tabla
View(variables)

# Leer tabla "abiotic_variables.txt" y que los nombres de las filas sean el identificador de la muestra
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)

# Explorar la tabla variables

View(variables)
dim(variables)
summary(variables)

View(as.data.frame(summary(variables)))

### Ejercicio 9. Acceder a los elementos de la tabla
dim(variables)

# Columnas
# una sola columna
variables[,3]
variables$Total_Co

# Dos o mas columnas seguidas
variables[,1:3]

# Dos o mas columnas en desorden 
variables[,c(2,5,6,1)]
variables[,c(22:25,4,1:3)]

# Filas
# una sola fila
variables[1,]

# Dos o mas filas seguidas
variables[3:6,]

# Dos o mas columnas en desorden 
variables[c(12,6,1),]

costa <- variables[1:5, 34:35]

# Con un valor especifico con los nombres de las columnas o filas
# una sola variable columnas
colnames(variables)

which(colnames(variables)=="Heneicosane")
variables[,which(colnames(variables)=="Heneicosane")]

# dos o mas variables
variables_interes <- c("Heneicosane", "Total_Ba", "Hexacosane")
which(colnames(variables) %in% variables_interes)
variables[,which(colnames(variables) %in% variables_interes)]

# una sola variable filas
which(rownames(variables)=="Someras_S2")
variables[which(rownames(variables)=="Someras_S2"),]

# dos o mas variables
variables_interes <- c("Costa_S1", "Costa_S2", "Profundas_S4")
which(rownames(variables) %in% variables_interes)
variables[which(rownames(variables) %in% variables_interes),]

# como cambia el resultado usando  el operador "=="
variables[which(rownames(variables) == variables_interes),]

# con un rango determinado de valores
summary(variables$Phenanthrene)

# Obtener el valor
variables$Phenanthrene[which(variables$Phenanthrene>7)]
variables[which(variables$Phenanthrene>7), which(colnames(variables)=="Phenanthrene")]

variables$Phenanthrene[which(variables$Phenanthrene>=8.0484)]

# Obtener el nombre de la estacion
rownames(variables)[which(variables$Phenanthrene>=7)]
variables[which(variables$Phenanthrene>7),17:18]

### Ejercicio 10. Adicion de columnas y filas a tablas
# Crear un objetos con una variable extra

extra_columna <- data.frame(Col_extra = c(rnorm(5, 31.8762, 0.233), 
                                          rnorm(5, 41.6213, 0.278), 
                                          rnorm(5, 11.4534, 0.3123)))
View(extra_columna)
class(extra_columna)
str(extra_columna)

extra_fila <- data.frame(variables[2,]+2)

# Cambiar nombre de la fila
rownames(extra_fila) <- "Fila_extra"

# unir las columnas con cbind
dim(variables)
dim(extra_columna)

tabla_con_columna_extra <- cbind(variables, extra_columna)
tabla_con_columna_extra <- cbind(variables[,1:2], 
                                 extra_columna, variables[,3:35])
View(tabla_con_columna_extra)

# unir las filas con rbind
dim(extra_fila)
dim(variables)
tabla_con_fila_extra <- rbind(extra_fila, variables)
View(tabla_con_fila_extra)

### Ejercicio 11. Generacion de matrices
# generar una matrix vacia
nueva_tabla <- matrix(nrow=15, ncol=35)
View(nueva_tabla)
class(nueva_tabla)

# generar una matrix con datos
nueva_tabla <- matrix(data=0, nrow=15, ncol=35)

# Cambiar nombres de columnas y filas

colnames(nueva_tabla) <- colnames(variables)
rownames(nueva_tabla) <- rownames(variables)

### Ejercicio 12. Escritura de datos
# texto delimitado por tabuladores
write.table(nueva_tabla, "tablas/tabla_vacia.txt", 
            sep="\t", quote=FALSE, 
            row.names= TRUE, col.names= TRUE)

# texto delimitado por comas
write.csv(nueva_tabla, "tablas/tabla_vacia.csv", 
          quote=FALSE, row.names=TRUE)

# Listar archivos de un directorio

dir ("tablas/")

### Ejercicio 13. Estructuras de control
# Ciclos FOR
View(variables)
as.data.frame(colnames(variables))
HC_alifaticos <- colnames(variables)[1:13]
HC_aromaticos <- colnames(variables)[14:21]

nueva_tabla <- matrix(ncol=4, nrow=dim(variables)[1])
head(nueva_tabla)
colnames(nueva_tabla) <- c("HC_alifaticos_totales", 
                           "HC_aromaticos_totales", 
                           "Organic_Matter", "Deep")
rownames(nueva_tabla) <- rownames(variables)

num_alif <- which(colnames(variables)%in%HC_alifaticos)
num_arom <- which(colnames(variables)%in% HC_aromaticos)

i <- 1
for (i in 1:dim(nueva_tabla)[1]){
  nueva_tabla[i,1] <- rowSums(variables[i,num_alif])
  nueva_tabla[i,2] <- rowSums(variables[i,num_arom])
  nueva_tabla[i,3] <- variables[i, which(colnames(variables)=="Organic_Matter")]
  nueva_tabla[i,4] <- variables[i, which(colnames(variables)=="Deep")]
}

head(nueva_tabla)


# if and else
if (10>50) {
  print("Verdadero")
} else {
  print ("Falso")
}

# ifelse 
num <- 1:10
ifelse(num %% 2 == 0, "Par", "Non")

# ifelse para decodificar variables
num <- c(1,0,0,0,0,0,1,1,0,1,1,0)
num <- ifelse(num == 0, "Hombre", "Mujer")
num

# while
count <- 0
while (count <= 10){
  print(count)
  count <- count + 1
}


### Ejercicio 14. Familia apply --> apply
View(variables)

# Extraer una tabla con los valores de los HC alifaticos
HC_alifaticos_tab <- variables[,1:13]
View(HC_alifaticos_tab)

# Sacar la media por de cada HC alifatico (columnas)

medias_HC_alif <- apply(HC_alifaticos_tab, 2, mean)
medias_HC_alif

summary(HC_alifaticos_tab)

# Sacar el valor maximo de todos los HC alifaticos por muestra (filas)
max_HC_alif_muestra <- apply(HC_alifaticos_tab, 1, max)
max_HC_alif_muestra

summary(t(HC_alifaticos_tab))

### Ejercicio 15. Familia apply --> sapply
View(nueva_tabla)
class(nueva_tabla)
nueva_tabla <- as.data.frame(nueva_tabla)
nueva_tabla$Clase <- sapply(as.character(rownames(nueva_tabla)), function(x){strsplit(x, "_")[[1]][1]}) 

nueva_tabla$Clase[which(nueva_tabla$Clase=="Costa")] <- "Costeras"

head(nueva_tabla)
View(nueva_tabla)
summary(nueva_tabla)
nueva_tabla$Clase <- as.factor(nueva_tabla$Clase)
summary(nueva_tabla)

library(ggplot2)

ggplot(nueva_tabla, aes(x=Clase, y=Organic_Matter, color=Clase, shape=Clase)) +
 geom_boxplot() + theme_bw()

### Ejercicio 16. Listado de variables e Informacion de la sesion
ls()
sessionInfo()

